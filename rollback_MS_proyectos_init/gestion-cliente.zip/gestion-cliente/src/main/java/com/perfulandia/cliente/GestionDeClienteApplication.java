package com.perfulandia.cliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeClienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDeClienteApplication.class, args);
	}

}
