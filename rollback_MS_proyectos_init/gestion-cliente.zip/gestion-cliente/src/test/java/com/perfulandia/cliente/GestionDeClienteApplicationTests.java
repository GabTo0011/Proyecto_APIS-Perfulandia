package com.perfulandia.cliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeClienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
