package com.perfulandia.vendedor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestionDeVendedorApplicationTests {

	@Test
	void contextLoads() {
	}

}
