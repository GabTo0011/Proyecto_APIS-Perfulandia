package com.perfulandia.vendedor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionDeVendedorApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionDeVendedorApplication.class, args);
	}

}
